package comp.graphics;

import java.awt.*;

public class StatusBar extends Panel{
	public Pan pan1, pan2, pan3;
	public String s1, s2, s3;
	
	public StatusBar(int w, int h){
		super();
		setLayout(new BorderLayout(10, 10));
		Panel pan = new Panel();
		
		pan1 = new Pan();
		add(pan1);
		pan1.setBounds(0, 0, w / 3, h);
		
		pan2 = new Pan();
		add(pan2);
		pan2.setBounds(w / 3 - 3, 0, w / 3, h);
		
		pan3 = new Pan();
		add(pan3);
		pan3.setBounds((2 * w) / 3 - 6, 0, w / 3, h);
		
		add("Center", pan);
	}
	
	public void setText(String s1, String s2, String s3){
		pan1.setText(s1);
		pan2.setText(s2);
		pan3.setText(s3);
	}
	
}